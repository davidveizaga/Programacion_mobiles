package com.example.ejemplo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    var tag="infodev"
    //vectores
    var vect : Array<String> = arrayOf("luz","Telefono","Agua")
    //crear una matriz
    var matriz = arrayOf(
        intArrayOf(1,2,3),
        intArrayOf(4,5,6),
        intArrayOf(7,8,9,10,11,12)
    )
    //coleccion Set
    var clientesVip : Set<Int> = setOf(1234,567,89)
    var mezclado = setOf(123,56.0,"roberto","C")
    var clientes : MutableSet<Int> = mutableSetOf(123,569,369)
    //coleccion Lista
    var Lista : List<Int> = listOf(1,2,3,4,5,6)
    var listamutable : MutableList<Int> = mutableListOf()
    //coleccion map
    var refrescos : Map<Int,String> = mapOf(
        1 to "CocaCola",
        2 to "Fanta",
        3 to "Sprite"
    )
    var inversiones = mutableMapOf<String,Float>()
    fun mostramutablemap(){
        Log.w(tag,"Mostrar mutableMap")
        inversiones.put("CocaCola",50F)
        inversiones.put("Fanta",250F)
        inversiones.put("Sprite",1550F)
        for ( i in inversiones){
            Log.e(tag,i.toString())
        }
    }
    fun mostrarmap(){
        Log.w(tag,"Mostrar Map")

        for (i in refrescos){
            Log.e(tag,i.toString())
        }
    }

    fun mostrarmutablelist(){
        Log.w(tag,"Mutable list")
        listamutable.add(0,69)
        listamutable.add(58)
        listamutable.add(36)
        for (i in listamutable){
            Log.e(tag,i.toString())
        }
    }

    fun mostrarLista(){
        Log.w(tag,"Mostrar lista")
        for (i in Lista){
            Log.e(tag,i.toString())
        }
    }
    fun mostrarmutableSet(){
        clientes.add(3)
        clientes.add(63)

        Log.w(tag,"MutableSet")
        for (i in clientes){
            Log.e(tag,i.toString())
        }
    }

    fun mostrarSet(){
        Log.w(tag,"Clientes vip")
        Log.e(tag,clientesVip.toString())
        Log.e(tag,"tamaño : ${clientesVip.size}" )
        if (clientesVip.contains(124)){
            Log.e(tag,"El cliente 1234 esta en la lista")
        }else{
            Log.e(tag,"EL cliente 124 no esta en la lista")
        }
    }



        fun mostrarmatriz(){
        Log.w(tag,"Mostra Matriz")
        for (i in (0 until matriz.size)){
            for (j in (0 until matriz[i].size)){
                Log.e(tag,"posiciones:[$i][$j]: ${matriz[i][j]}")
            }
        }
    }
    fun mostrarVector(){
        //primera forma de for
        Log.w(tag,"Primera forma de for")
        for (i in vect){
            Log.e(tag,i.toString())
        }
        //segunda forma de for
        Log.w(tag,"Segunda forma de for")
        for (i in vect.indices){
            Log.e(tag,vect.get(i))
        }
        //tercera forma de for
        Log.w(tag,"Tercera forma de for")
        for (i in 0.. vect.size-1){
            Log.e(tag,"${i+1}: ${vect.get(i)}")


        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mostrarVector()
        mostrarmatriz()
        mostrarSet()
        mostrarmutableSet()
        mostrarLista()
        mostrarmutablelist()
        mostrarmap()
        mostramutablemap()
    }
}