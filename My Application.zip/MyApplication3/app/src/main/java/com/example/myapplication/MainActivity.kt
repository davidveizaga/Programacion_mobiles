package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.calculadora)
        //funcion para sumar
        fun sumar(view: View){
            val valor1=et1.text.toString()
            val valor2=et2.text.toString()
            if (valor1!=""&& valor2!="") {
                val num1 = valor1.toInt()
                val num2 = valor2.toInt()
                val suma = num1 + num2
                val resultado = suma.toString()
                tv1.text = resultado
            }else{
                Toast.makeText(this,"Ingrese valores en los campoes",Toast.LENGTH_SHORT).show()
            }
        }
        //funcion para restar
        fun restar(view: View){
            val valor1=et1.text.toString()
            val valor2=et2.text.toString()
            if (valor1!=""&& valor2!="") {
                val num1 = valor1.toInt()
                val num2 = valor2.toInt()
                val resta = num1 - num2
                val resultado = resta.toString()
                tv1.text = resultado
            }else{
                Toast.makeText(this,"Ingrese valores en los campoes",Toast.LENGTH_SHORT).show()
            }
        }
        //funcion para multiplicar
        fun Multiplicar(view: View){
            val valor1=et1.text.toString()
            val valor2=et2.text.toString()
            if (valor1!=""&& valor2!="") {
                val num1 = valor1.toInt()
                val num2 = valor2.toInt()
                val multiplicar = num1 * num2
                val resultado = multiplicar.toString()
                tv1.text = resultado
            }else{
                Toast.makeText(this,"Ingrese valores en los campoes",Toast.LENGTH_SHORT).show()
            }
        }
        //funcion para dividir
        fun Dividir(view: View){
            val valor1=et1.text.toString()
            val valor2=et2.text.toString()
            if (valor1!=""&& valor2!="") {
                val num1 = valor1.toInt()
                val num2 = valor2.toInt()
                val dividir = num1 / num2
                val resultado = dividir.toString()
                tv1.text = resultado
            }else{
                Toast.makeText(this,"Ingrese valores en los campoes",Toast.LENGTH_SHORT).show()
            }
        }
    }
}